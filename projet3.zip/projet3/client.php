<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: Page_Connexion.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sportify: Consultation Sportive - Client</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background-color: #191414;
        color: white;
    }
    .wrapper {
        width: 100%;
        margin: 0 auto;
    }
    header {
        background-color: #191414;
        padding: 20px;
        text-align: center;
        position: relative;
        border-bottom: 2px solid #1DB954;
    }
    header h1 {
        margin: 0;
        font-size: 2em;
        color: white;
    }
    header span {
        color: #1DB954;
    }
    nav {
        background-color: #282828;
        padding: 10px 0;
        text-align: center;
    }
    nav a {
        display: inline-block;
        margin: 0 10px;
        padding: 10px 20px;
        background-color: #1DB954;
        border-radius: 10px;
        text-decoration: none;
        color: white;
        font-weight: bold;
    }
    nav a:hover {
        background-color: #1ed760;
    }
    .content {
        padding: 50px;
        color: white;
    }
    .event-section, .bulletin-section {
        margin: 0 auto;
    }
    .event-section h2, .bulletin-section h2 {
        color: #1DB954;
    }
    .carousel, .bulletin {
        background-color: #282828;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
        position: relative;
        overflow: hidden;
        text-align: center;
    }
    .carousel img, .bulletin img {
        width: 28%;
        height: auto;
        display: none;
        margin: 0 auto;
    }
    .carousel img.active, .bulletin img.active {
        display: block;
    }
    .carousel-controls, .bulletin-controls {
        position: absolute;
        top: 50%;
        width: 100%;
        display: flex;
        justify-content: space-between;
        transform: translateY(-50%);
    }
    .carousel-controls button, .bulletin-controls button {
        background-color: #1DB954;
        border: none;
        padding: 10px;
        cursor: pointer;
    }
    .description {
        margin-top: 15px;
        color: #b3b3b3;
    }
    footer {
        background-color: #282828;
        text-align: center;
        padding: 20px 0;
        border-top: 2px solid #1DB954;
        color: #b3b3b3;
    }
    .logo {
        position: absolute;
        top: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
    }
    .map {
        margin-top: 20px;
    }
</style>
   
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Consultation Sportive</h1>
            <img src="logo.jpg" alt="Sportify Logo" class="logo">
        </header>
        <nav>
            <a href="parcourir.php">Tout Parcourir</a>
            <a href="Page_Recherche2.php">Recherche</a>
            <a href="rendez-vous.php">Rendez-vous</a>
            <a href="compte_client.php">Votre Compte</a>
            <a href="Page_NoLogin.html">Déconnexion</a>
        </nav>
        <div class="content">
            <div class="event-section">
                <h2>Evènement de la semaine</h2>
                <div class="carousel">
                    <img src="Photo_Caroussel/AllStar.png" alt="Event 1" class="active">
                    <img src="Photo_Caroussel/2.png" alt="Event 2">
                    <img src="Photo_Caroussel/3.png" alt="Event 3">
                    <div class="carousel-controls">
                        <button onclick="prevSlide('carousel')">◄</button>
                        <button onclick="nextSlide('carousel')">►</button>
                    </div>
                    <div class="description">Découvrez l'évènement marquant de la semaine : Le match Inge All Star Game à Suzanne Lenglen !</div>
                </div>
            </div>
            <div class="bulletin-section">
                <h2>Bulletin Sportif de la semaine</h2>
                <div class="bulletin">
                    <img src="Photo_Caroussel/Quarter finals (3).png" alt="Bulletin 1" class="active">
                    <img src="Photo_Caroussel/1.png" alt="Bulletin 2">
                    <div class="bulletin-controls">
                        <button onclick="prevSlide('bulletin')">◄</button>
                        <button onclick="nextSlide('bulletin')">►</button>
                    </div>
                    <div class="description">Les dernières nouvelles importantes liées aux évènements sportifs, Quart de finale Inge3 League finis, demis finale jeudi soyez present !</div>
                </div>
            </div>
            <div class="map">
                <h2>Localisation</h2>
                <div>
                    <p>Retrouvez-nous sur Google Maps pour voir l'adresse physique de Sportify.</p>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2624.912635133455!2d2.292292315674342!3d48.84935697928709!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e671d84bce751b%3A0x40b82c3688c9460!2s15%20Rue%20Sextius%20Michel%2C%2075015%20Paris%2C%20France!5e0!3m2!1sen!2sus!4v1627814719123!5m2!1sen!2sus" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
            </div>
        </div>
        <footer>
            <p>Contactez-nous par mail : Sportify@gmail.com , téléphone 06 69 51 86 95, ou visitez-nous à notre adresse physique : 15 Rue sextius michel </p>
        </footer>
    </div>
    <script>
        let carouselIndex = 0;
        let bulletinIndex = 0;

        function showSlide(section, index) {
            const slides = document.querySelectorAll(`.${section} img`);
            if (index >= slides.length) index = 0;
            if (index < 0) index = slides.length - 1;
            for (let i = 0; i < slides.length; i++) {
                slides[i].classList.remove('active');
            }
            slides[index].classList.add('active');
            if (section === 'carousel') {
                carouselIndex = index;
            } else if (section === 'bulletin') {
                bulletinIndex = index;
            }
        }

        function nextSlide(section) {
            if (section === 'carousel') {
                showSlide(section, carouselIndex + 1);
            } else if (section === 'bulletin') {
                showSlide(section, bulletinIndex + 1);
            }
        }

        function prevSlide(section) {
            if (section === 'carousel') {
                showSlide(section, carouselIndex - 1);
            } else if (section === 'bulletin') {
                showSlide(section, bulletinIndex - 1);
            }
        }
    </script>
</body>
</html>
