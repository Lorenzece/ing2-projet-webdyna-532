<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

$servername = "localhost";
$username = "root2";
$password = "root";
$dbname = "projet";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée: " . $conn->connect_error);
}


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $coach_nom = $_POST['coach_nom'];

  
    $client_query = "SELECT name FROM login WHERE id = ?";
    $stmt = $conn->prepare($client_query);
    if (!$stmt) {
        die("Erreur de préparation de la requête (client_query): " . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($client_nom);
    $stmt->fetch();
    $stmt->close();

    if (!$client_nom) {
        die("Client non trouvé.");
    }

    
    $coach_id_query = "SELECT id FROM coach WHERE nom = ?";
    $stmt = $conn->prepare($coach_id_query);
    if (!$stmt) {
        die("Erreur de préparation de la requête (coach_id_query): " . $conn->error);
    }
    $stmt->bind_param("s", $coach_nom);
    $stmt->execute();
    $stmt->bind_result($coach_id);
    $stmt->fetch();
    $stmt->close();

    if ($coach_id) {
       
        $sql = "INSERT INTO rendezvous (client_id, client_nom, coach_id, coach_nom) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Erreur de préparation de la requête d'insertion: " . $conn->error);
        }
        $stmt->bind_param("isis", $user_id, $client_nom, $coach_id, $coach_nom);

        if ($stmt->execute()) {
           
            header("Location: rendez-vous.php");
            exit();
        } else {
            echo "Erreur lors de l'exécution de la requête d'insertion: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Coach non trouvé.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rendez-vous - Sportify</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #191414;
            color: white;
        }
        .wrapper {
            width: 100%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        header {
            background-color: #191414;
            padding: 20px;
            text-align: center;
            border-bottom: 2px solid #1DB954;
            width: 100%;
        }
        header h1 {
            margin: 0;
            font-size: 2em;
            color: white;
        }
        header span {
            color: #1DB954;
        }
        .appointment-container {
            background-color: #282828;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
            width: 400px;
            margin-top: 20px;
        }
        .appointment-container h2 {
            margin: 0 0 20px 0;
            color: #1DB954;
            text-align: center;
        }
        .appointment-container label {
            display: block;
            margin-bottom: 10px;
            color: #b3b3b3;
        }
        .appointment-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: none;
            border-radius: 5px;
        }
        .appointment-container button {
            width: 100%;
            padding: 10px;
            background-color: #1DB954;
            border: none;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        .appointment-container button:hover {
            background-color: #1ed760;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Rendez-vous</h1>
        </header>
        <div class="appointment-container">
            <h2>Planifiez votre rendez-vous</h2>
            <form action="rendezvous.php" method="POST">
                <label for="coach-nom">Nom du Coach :</label>
                <input type="text" id="coach-nom" name="coach_nom" required>
                <button type="submit">Enregistrer le rendez-vous</button>
            </form>
        </div>
    </div>
</body>
</html>
