<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['prenom'] = $_POST['prenom'];
    $_SESSION['adresse_ligne1'] = $_POST['adresse_ligne1'];
    $_SESSION['adresse_ligne2'] = $_POST['adresse_ligne2'];
    $_SESSION['ville'] = $_POST['ville'];
    $_SESSION['code_postal'] = $_POST['code_postal'];
    $_SESSION['pays'] = $_POST['pays'];
    $_SESSION['telephone'] = $_POST['telephone'];
    $_SESSION['carte_etudiant'] = $_POST['carte_etudiant'];

    header("Location: paiement2.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informations Personnelles - Sportify</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #191414;
            color: white;
        }
        .wrapper {
            width: 100%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        header {
            background-color: #191414;
            padding: 20px;
            text-align: center;
            border-bottom: 2px solid #1DB954;
            width: 100%;
        }
        header h1 {
            margin: 0;
            font-size: 2em;
            color: white;
        }
        header span {
            color: #1DB954;
        }
        .form-container {
            background-color: #282828;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
            width: 400px;
            margin-top: 20px;
        }
        .form-container h2 {
            margin: 0 0 20px 0;
            color: #1DB954;
            text-align: center;
        }
        .form-container label {
            display: block;
            margin-bottom: 10px;
            color: #b3b3b3;
        }
        .form-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: none;
            border-radius: 5px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: #1DB954;
            border: none;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #1ed760;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Informations Personnelles</h1>
        </header>
        <div class="form-container">
            <h2>Entrez vos informations personnelles</h2>
            <form action="infos_perso.php" method="POST">
                <label for="name">Nom :</label>
                <input type="text" id="name" name="name" required>
                <label for="prenom">Prénom :</label>
                <input type="text" id="prenom" name="prenom" required>
                <label for="adresse_ligne1">Adresse Ligne 1 :</label>
                <input type="text" id="adresse_ligne1" name="adresse_ligne1" required>
                <label for="adresse_ligne2">Adresse Ligne 2 :</label>
                <input type="text" id="adresse_ligne2" name="adresse_ligne2">
                <label for="ville">Ville :</label>
                <input type="text" id="ville" name="ville" required>
                <label for="code_postal">Code Postal :</label>
                <input type="text" id="code_postal" name="code_postal" required>
                <label for="pays">Pays :</label>
                <input type="text" id="pays" name="pays" required>
                <label for="telephone">Numéro de téléphone :</label>
                <input type="text" id="telephone" name="telephone" required>
                <label for="carte_etudiant">Carte Etudiant :</label>
                <input type="text" id="carte_etudiant" name="carte_etudiant" required>
                <button type="submit">Suivant</button>
            </form>
        </div>
    </div>
</body>
</html>
