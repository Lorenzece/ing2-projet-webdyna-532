-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 02, 2024 at 06:06 PM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projet`
--

-- --------------------------------------------------------

--
-- Table structure for table `coach`
--

CREATE TABLE `coach` (
  `ID` int(11) NOT NULL,
  `Nom` varchar(255) NOT NULL,
  `Activité` varchar(255) NOT NULL,
  `Photo` varchar(255) NOT NULL,
  `adresse bureau` varchar(255) NOT NULL,
  `disponibilité` varchar(255) NOT NULL,
  `CV` varchar(255) NOT NULL,
  `courrier` varchar(255) NOT NULL,
  `téléphone` varchar(255) NOT NULL,
  `Salle de sport` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `coach`
--

INSERT INTO `coach` (`ID`, `Nom`, `Activité`, `Photo`, `adresse bureau`, `disponibilité`, `CV`, `courrier`, `téléphone`, `Salle de sport`) VALUES
(1, 'Hercule Barbell', 'Musculation', 'Photo_Coach_Masculin\\photo1.jpg', '123 Rue de la Force, 75001 Paris, France', 'Lundi : 16h - 21h\nMardi : 16h - 21h\nMercredi : - - - \nJeudi : 16h - 21h\nVendredi : 16h - 21h\nSamedi : 14h - 19h\nDimanche : - - - ', 'CV\\CV1.png', 'hercule.barbell@example.com', '06 12 34 56 78', 'Salle de Sport Omnes'),
(2, 'Eva Lucian', 'Fitness', 'Photo_Coach_Féminin\\photo2.jpg', '45 Avenue de la Vitalité, 92100 Boulogne-Billancourt, France', 'Lundi : 14h - 20h\nMardi : 14h - 20h\nMercredi : 14h - 20h\nJeudi : 14h - 20h\nVendredi : 14h - 20h\nSamedi : - - -\nDimanche : - - -', 'CV\\CV2.png', 'eva.lucian@example.com', '06 98 76 54 32', 'Salle de Sport Omnes'),
(3, 'Pierre Lonné', 'Biking', 'Photo_Coach_Masculin\\photo3.jpg', '78 Rue de la Pédale, 92200 Neuilly-sur-Seine, France', 'Lundi : 10h - 20h\r\nMardi : 10h - 20h\r\nMercredi : 10h - 20h\r\nJeudi : 10h - 20h\r\nVendredi : 10h - 20h\r\nSamedi : 10h - 20h\r\nDimanche : - - -', 'CV\\CV3.png', 'pierre.lonne@example.com', '06 45 67 89 01', 'Salle de Sport Omnes'),
(4, 'Céline Pulsar', 'Cardio-Training', 'Photo_Coach_Féminin\\photo4.jpg', '32 Rue du Souffle, 92300 Levallois-Perret, France', 'Lundi : 17h - 21h\nMardi : 17h - 21h\nMercredi : 17h - 21h\nJeudi : 17h - 21h\nVendredi : 17h - 21h\nSamedi : 10h - 19h\nDimanche : - - - ', 'CV\\CV4.png', 'celine.pulsar@example.com', '06 12 34 56 78', 'Salle de Sport Omnes'),
(5, 'Claude Hernandez', 'Cours Collectifs', 'Photo_Coach_Masculin\\photo5.jpg', '56 Rue de l\'Énergie, 94110 Arcueil, France', 'Lundi : 18h - 23h \r\nMardi : 18h - 23h \r\nMercredi : 18h - 23h \r\nJeudi : 18h - 23h \r\nVendredi : 18h - 23h \r\nSamedi : - - - \r\nDimanche : - - -', 'CV\\CV5.png', 'claude.hernandez@example.com', '06 78 90 12 34', 'Salle de Sport Omnes'),
(6, 'Sophie Bleur', 'Basketball', 'Photo_Coach_Féminin\\photo6.jpg', '23 Rue du Panier, 93160 Noisy-le-Grand, France', 'Lundi : 9H - 21 h\nMardi : 9H - 21 h\nMercredi : 9H - 21 h\nJeudi : 9H - 21 h\nVendredi : 9H - 21 h\nSamedi : - - -\nDimanche : - - -', 'CV\\CV6.png', 'sophie.bleur@example.com', '06 54 32 10 98', 'Salle de Sport Omnes'),
(7, 'Alex Bill', 'Football', 'Photo_Coach_Masculin\\photo7.jpg', '17 Avenue des Buttes, 92130 Issy-les-Moulineaux, France', 'Lundi : 17h - 23h\r\nMardi : 17h - 23h\r\nMercredi : 17h - 23h\r\nJeudi : 17h - 23h\r\nVendredi : 17h - 23h\r\nSamedi : 10h - 20h\r\nDimanche : 10h - 13h', 'CV\\CV7.png', 'alex.bill@example.com', '06 34 56 78 90', 'Salle de Sport Omnes'),
(8, 'Léa Bigorne', 'Rugby', 'Photo_Coach_Féminin\\photo8.jpg', '12 Rue du Stade, 93170 Bagnolet, France', 'Lundi : 10h - 22h\r\nMardi : 10h - 22h\r\nMercredi : 10h - 22h\r\nJeudi : 10h - 22h\r\nVendredi : 10h - 22h\r\nSamedi : 10h - 19h\r\nDimanche : - - -', 'CV\\CV8.png', 'lea.bigorne@example.com', '06 23 45 67 89', 'Salle de Sport Omnes'),
(9, 'Pascal Set', 'Tennis', 'Photo_Coach_Masculin\\photo9.jpg', '89 Avenue des Courtisans, 94130 Nogent-sur-Marne, France', 'Lundi : 14h - 20h\r\nMardi : 14h - 20h\r\nMercredi : 14h - 20h\r\nJeudi : 14h - 20h\r\nVendredi : 14h - 20h\r\nSamedi : 10h - 20h\r\nDimanche : 10h - 13h', 'CV\\CV9.png', 'pascal.set@example.com', '06 89 76 54 32', 'Salle de Sport Omnes'),
(10, 'Marine Plouf', 'Natation', 'Photo_Coach_Féminin\\photo10.jpg', '14 Rue des Ondines, 94220 Charenton-le-Pont, France', 'Lundi : 10h - 19h \r\nMardi : 10h - 19h \r\nMercredi : 10h - 19h \r\nJeudi : 10h - 19h \r\nVendredi : 10h - 19h \r\nSamedi : - - -\r\nDimanche : - - -', 'CV\\CV10.png', 'marine.plouf@example.com', '06 98 75 54 32', 'Salle de Sport Omnes'),
(11, 'Dorian Vaché', 'Plongeon', 'Photo_Coach_Masculin\\photo11.jpg', '5 Rue des Halles, 92100 Boulogne-Billancourt, France', 'Lundi : 10h - 20h\r\nMardi : 14h - 23h\r\nMercredi : 10h - 20h\r\nJeudi : 10h - 20h\r\nVendredi : 14h - 23h\r\nSamedi : 10h - 20h\r\nDimanche : - - -', 'CV\\CV11.png', 'dorian.vache@example.com', '06 78 12 34 56', 'Salle de Sport Omnes');

-- --------------------------------------------------------

--
-- Table structure for table `coordonneespaiement`
--

CREATE TABLE `coordonneespaiement` (
  `coordonnees_id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `adresse_ligne1` varchar(255) NOT NULL,
  `adresse_ligne2` varchar(255) DEFAULT NULL,
  `ville` varchar(100) NOT NULL,
  `code_postal` varchar(20) NOT NULL,
  `pays` varchar(50) NOT NULL,
  `numero_telephone` varchar(20) DEFAULT NULL,
  `carte_etudiant` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `coordonneespaiement`
--

INSERT INTO `coordonneespaiement` (`coordonnees_id`, `nom`, `prenom`, `adresse_ligne1`, `adresse_ligne2`, `ville`, `code_postal`, `pays`, `numero_telephone`, `carte_etudiant`) VALUES
(1, 'NomExample', 'PrenomExample', '123 Rue Exemple', 'Apt 4', 'ExempleVille', '12345', 'ExemplePays', '0123456789', '1234567890'),
(2, 'ss', 'ss', 'ss', 'ss', 'ss', '75007', 'FRANCE', NULL, NULL),
(3, 'ss', 'ss', 'ss', 'ss', 'ss', '75007', 'FRANCE', NULL, NULL),
(4, 'ss', 'ss', 'ss', 'ss', 'paris', '75', 'FRANCE', NULL, NULL),
(5, 'ss', 'ss', 'ss', 'ss', 'paris', '75', 'FRANCE', NULL, NULL),
(6, 'trabbia', 'lorenz', 'ece.ece', 'ece.ece.2', 'paris', '75001', 'FRANCE', NULL, NULL),
(7, 'ss', 'ss', 'ss', 'sss', 'PARIS', '1827', 'FRANCE', '293892123', '826293'),
(8, 'ss', 'ss', 'ss', 'sss', 'PARIS', '1827', 'FRANCE', '293892123', '826293'),
(9, 'ss', 'ss', 'ss', 'sss', 'PARIS', '1827', 'FRANCE', '293892123', '826293'),
(10, 'papa', 'papa', 'papa', 'papa', 'papa', '1234', 'papa', '1233', '12342'),
(11, 'papa', 'papa', 'papa', 'papa', 'papa', '1234', 'papa', '1233', '12342'),
(12, 'papa', 'papa', 'papa', 'papa', 'papa', '1234', 'papa', '1233', '12342'),
(13, 'papa', 'papa', 'papa', 'papa', 'papa', '1234', 'papa', '1233', '12342'),
(14, 'papa2', 'papa2', 'papa2', 'papa2', 'papa2', '2736', 'papa2', '1826', '13382'),
(15, 'eva', 'Eva1234', 'Eva1234', 'Eva1234Eva1234', 'Eva1234', '1234', 'Eva1234', '123', '1234'),
(16, 'TRABBIA', 'LORENZ', 'LORENZ', 'LORENZ', 'LORENZ', '75001', 'LORENZ', '17293', '1234'),
(17, 'TRABBIA', 'LORENZ', 'LORENZ', 'LORENZ', 'LORENZ', '75001', 'LORENZ', '17293', '1234'),
(18, 'trabbia', 'trabbia', 'trabbia', 'trabbia', 'trabbia', '123', 'trabbia', '123', '123'),
(19, 'trabbia', 'trabbia', 'trabbia', 'trabbia', 'trabbia', '123', 'trabbia', '123', '123'),
(20, 'TRABBIA', 'TRABBIA', 'TRABBIA', 'TRABBIA', 'TRABBIA', '123', 'TRABBIA', '123', '123'),
(21, 'TRABBIA', 'a', 'a', 'a', 'a', '12', 'a', '12', '12'),
(22, 'AA', 'AA', 'AA', 'AA', 'AA', '123', 'AA', '123', '123'),
(23, 'Eva Lucian', 'Eva Lucian', 'Eva Lucian', 'Eva Lucian', 'Eva Lucian', '123', 'FRANCE', '123', '123'),
(24, 'Eva Lucian', 'Eva Lucian', 'Eva Lucian', 'Eva Lucian', 'Eva Lucian', '123', 'Eva Lucian', '123', '123'),
(25, 'TRABBIA123', 'TRABBIA123', 'TRABBIA123', 'TRABBIA123', 'PARIS', '123', 'TRABBIA123', '123', '123'),
(26, 'Robin123', 'Robin123', 'Robin123', 'Robin123', 'Robin123', '123', 'Robin123', '123', '123'),
(27, 'Dorian1234', 'Dorian1234', 'Dorian1234', 'Dorian1234', 'Dorian1234', '123', 'Dorian1234', '123', '123'),
(28, 'fadi', 'fadi', 'fadi', 'fadi', 'fadi', '123', 'fadi', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `detailspaiement`
--

CREATE TABLE `detailspaiement` (
  `paiement_id` int(11) NOT NULL,
  `type_carte` enum('Visa','MasterCard','American Express','PayPal') NOT NULL,
  `numero_carte` varchar(20) NOT NULL,
  `nom_sur_carte` varchar(50) NOT NULL,
  `date_expiration` date NOT NULL,
  `code_securite` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `detailspaiement`
--

INSERT INTO `detailspaiement` (`paiement_id`, `type_carte`, `numero_carte`, `nom_sur_carte`, `date_expiration`, `code_securite`) VALUES
(1, 'Visa', '5836639815743483', 'Robin Buniere', '2025-12-31', '123'),
(2, 'Visa', '123', 'papa', '2024-08-01', '123'),
(3, 'Visa', '123', 'papa', '2024-08-01', '123'),
(4, 'Visa', '183', 'papa2', '2024-03-01', '273'),
(5, 'Visa', '1234', 'Eva1234', '2024-07-01', '123'),
(6, 'Visa', '123', 'LORENZ', '2024-07-01', '123'),
(7, 'Visa', '123', 'LORENZ', '2024-07-01', '123'),
(8, 'Visa', '123', 'trabbia', '2024-02-01', '123'),
(9, 'Visa', '123', 'trabbia', '2024-02-01', '123'),
(10, 'Visa', '123', 'TRABBIA', '2024-07-01', '123'),
(11, 'Visa', '12', 'aaa', '2024-03-01', '12'),
(12, 'Visa', '123', 'AA', '2024-08-01', '123'),
(13, 'Visa', '123', 'Eva Lucian', '2024-08-01', '123'),
(14, 'Visa', '123', 'Eva Lucian', '2024-03-01', '123'),
(15, 'Visa', '123', 'TRABBIA123', '2024-03-01', '123'),
(16, 'Visa', '232', 'Robin123', '2024-11-01', '123'),
(17, 'Visa', '123', 'Dorian1234', '2024-08-01', '123'),
(18, 'Visa', '123', 'fadi', '2024-03-01', '123');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `carte_etudiant` varchar(50) DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `password`, `role`, `carte_etudiant`, `adresse`) VALUES
(1, 'Hercule Barbell', 'hercule.barbell@exemple.com', 'Hercule1234', 'coach', 'non', 'non'),
(2, 'Eva Lucian', 'eva.lucian@exemple.com', 'Eva1234', 'coach', 'non', 'non'),
(3, 'Pierre Lonné', 'pierre.lonne@exemple.com', 'Pierre1234', 'coach', 'non', 'non'),
(4, 'Céline Pulsar', 'céline.pulsar@exemple.com', 'Céline1234', 'coach', 'non', 'non'),
(5, 'Claude Hernandez', 'claude.hernandez@exemple.com', 'Claude1234', 'coach', 'non', 'non'),
(6, 'Sophie Bleur', 'sophie.bleur@exemple.com', 'Sophie1234', 'coach', 'non', 'non'),
(7, 'Alex Bill', 'alex.bill@exemple.com', 'Alex1234', 'coach', 'non', 'non'),
(8, 'Léa Bigorne', 'léa.bigorne@exemple.com', 'Léa1234', 'coach', 'non', 'non'),
(9, 'Pascal Set', 'pascal.set@exemple.com', 'Pascal1234', 'coach', 'non', 'non'),
(10, 'Marine Plouf', 'marine.plouf@exemple.com', 'Marine1234', 'coach', 'non', 'non'),
(11, 'Dorian Vaché', 'dorian.vache@exemple.com', 'Dorian1234', 'coach', 'non', 'non'),
(12, 'Lorenz Trabbia', 'lorenz.trabbia@exemple.com', 'Lorenz1234', 'admin', 'non', 'non'),
(13, 'Elias Moussouni', 'elias.moussouni@exemple.com', 'Elias1234', 'admin', 'non', 'non'),
(14, 'Fadi Al Mikdad', 'fadi.almikdad@exemple.com', 'Fadi1234', 'admin', 'non', 'non'),
(15, 'Clement Baugeant', 'clement.baugeant@exemple.com', 'Clement1234', 'admin', 'non', 'non'),
(16, 'Raphael Maison', 'raphael.maison@exemple.com', 'Raphael1234', 'client', '495927507', '3 rue des potiers'),
(17, 'Robin Buniere', 'Robinbuniere@exemple.com', 'Robin123', 'client', '123456789', '3 rue poisson'),
(18, 'J', 'moussounielias@gmail.com', 'hola', 'client', '1', '13 Boulevard de l\'Hautil'),
(19, 'Elias', 'm@m.com', '123', 'client', '12', 'joueur');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender_id`, `receiver_id`, `message`, `timestamp`) VALUES
(1, 1, 2, 'typeshit', '2024-06-02 15:23:48'),
(2, 1, 2, 'yessir', '2024-06-02 15:25:19'),
(3, 1, 2, '4', '2024-06-02 15:58:19'),
(4, 1, 2, '14', '2024-06-02 15:58:26'),
(5, 1, 2, 'Yo tout le monde', '2024-06-02 16:33:34'),
(6, 1, 2, 'okay', '2024-06-02 16:33:42');

-- --------------------------------------------------------

--
-- Table structure for table `rendezvous`
--

CREATE TABLE `rendezvous` (
  `ID` int(11) NOT NULL,
  `coach_id` int(11) NOT NULL,
  `coach_nom` varchar(255) DEFAULT NULL,
  `client_ID` int(11) DEFAULT NULL,
  `client_nom` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `heure` time DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `document` varchar(255) DEFAULT NULL,
  `digicode` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rendezvous`
--

INSERT INTO `rendezvous` (`ID`, `coach_id`, `coach_nom`, `client_ID`, `client_nom`, `date`, `heure`, `adresse`, `document`, `digicode`) VALUES
(6, 10, 'Marine Plouf', 11, 'Dorian Vaché', NULL, NULL, NULL, NULL, NULL),
(7, 7, 'Alex Bill', 16, 'Raphael Maison', NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coach`
--
ALTER TABLE `coach`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_2` (`ID`);

--
-- Indexes for table `coordonneespaiement`
--
ALTER TABLE `coordonneespaiement`
  ADD PRIMARY KEY (`coordonnees_id`);

--
-- Indexes for table `detailspaiement`
--
ALTER TABLE `detailspaiement`
  ADD PRIMARY KEY (`paiement_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `rendezvous`
--
ALTER TABLE `rendezvous`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `coach`
--
ALTER TABLE `coach`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `coordonneespaiement`
--
ALTER TABLE `coordonneespaiement`
  MODIFY `coordonnees_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `detailspaiement`
--
ALTER TABLE `detailspaiement`
  MODIFY `paiement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rendezvous`
--
ALTER TABLE `rendezvous`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `login` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `login` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
