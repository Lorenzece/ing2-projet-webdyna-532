<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: Page_Connexion.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "projet";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("La connexion a échoué: " . $conn->connect_error);
}

$email = $_SESSION['email'];

$sql = "SELECT role FROM login WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$role = $user['role'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tout Parcourir - Sportify</title>
    <link rel="stylesheet" href="Style3.css">
</head>
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Tout parcourir</h1>
        </header>
        <nav>
            <a href="<?php echo ($role == 'admin') ? 'admin.php' : (($role == 'coach') ? 'coach.php' : 'client.php'); ?>">Accueil</a>
            <a href="Page_Recherche2.php">Recherche</a>
            <a href="rendez-vous.php">Rendez-vous</a>
            <a href="<?php echo ($role == 'admin') ? 'compte_admin.php' : (($role == 'coach') ? 'compte_coach.php' : 'compte_client.php'); ?>">Votre Compte</a>
            <a href="Page_NoLogin.html">Déconnexion</a>
        </nav>
        <div class="content">
            <p>Il s’agit de toutes les catégories des services disponibles chez Sportify. Il y a trois catégories dans ce service :</p>
            <div class="categories">
                <div class="category" onclick="window.location.href='activites_sportives.php'">
                    <h2>Activités sportives</h2>
                </div>
                <div class="category" onclick="window.location.href='sports_de_competition.php'">
                    <h2>Les Sports de compétition</h2>
                </div>
                <div class="category" onclick="window.location.href='salle_de_sport_omnes.php'">
                    <h2>Salle de sport Omnes</h2>
                </div>
            </div>
        </div>
        <footer>
            <p>Contactez-nous par mail, téléphone, ou visitez-nous à notre adresse physique.</p>
        </footer>
    </div>
</body>
</html>
