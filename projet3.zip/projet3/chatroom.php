<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatroom</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #191414; /* Spotify's black background */
            color: white; /* White text for contrast */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .wrapper {
            width: 100%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            flex: 1;
            align-items: center;
        }

        header {
            background-color: #191414; /* Same as body for a seamless look */
            padding: 20px;
            text-align: center;
            border-bottom: 2px solid #1DB954; /* Spotify green */
            width: 100%;
        }

        header h1 {
            margin: 0;
            font-size: 2em;
            color: white;
        }

        header span {
            color: #1DB954; /* Spotify green */
        }

        nav {
            background-color: #282828; /* Dark grey for contrast */
            padding: 10px 0;
            text-align: center;
            width: 100%;
        }

        nav a {
            display: inline-block;
            margin: 0 10px;
            padding: 10px 20px;
            background-color: #1DB954; /* Spotify green */
            border-radius: 10px;
            text-decoration: none;
            color: white; /* White text for contrast */
            font-weight: bold;
        }

        nav a:hover {
            background-color: #1ed760; /* Slightly lighter green for hover effect */
        }

        .container {
            display: flex;
            justify-content: space-between;
            padding: 2rem;
            flex: 1;
        }

        .chatbox, .emailbox {
            background-color: #282828; /* Dark grey for contrast */
            padding: 1rem;
            border-radius: 10px;
            width: 45%;
        }

        .chatbox {
            margin-right: 2rem;
        }

        .chatbox h3, .emailbox h3 {
            color: #1DB954; /* Spotify green */
        }

        .chatbox .messages {
            height: 300px;
            overflow-y: scroll;
            border: 1px solid #1DB954; /* Spotify green */
            padding: 1rem;
            margin-bottom: 1rem;
        }

        .chatbox .messages p {
            margin: 0.5rem 0;
        }

        .chatbox input, .emailbox input, .emailbox textarea {
            width: 100%;
            padding: 0.5rem;
            margin: 0.5rem 0;
            border: none;
            border-radius: 5px;
        }

        .chatbox button, .emailbox button {
            width: 100%;
            padding: 0.5rem;
            background-color: #1DB954; /* Spotify green */
            border: none;
            border-radius: 5px;
            color: white; /* White text for contrast */
            font-weight: bold;
        }

        .chatbox button:hover, .emailbox button:hover {
            background-color: #1ed760; /* Slightly lighter green for hover effect */
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1>Chatroom <span>Sportify</span></h1>
        </header>
        <nav>
            <a href="<?php echo ($role == 'admin') ? 'admin.php' : (($role == 'coach') ? 'coach.php' : 'client.php'); ?>">Accueil</a>
            <a href="Page_Recherche2.php">Recherche</a>
            <a href="connexion.php">Rendez-vous</a>
            <a href="<?php echo ($role == 'admin') ? 'compte_admin.php' : (($role == 'coach') ? 'compte_coach.php' : 'compte_client.php'); ?>">Votre Compte</a>
            <a href="Page_NoLogin.html">Déconnexion</a>
        </nav>
        <div class="container">
            <div class="chatbox">
                <h3>Chatroom</h3>
                <div class="messages" id="messageBox">
                    <!-- Messages will appear here -->
                </div>
                <input type="text" id="messageInput" placeholder="Tapez votre message...">
                <button onclick="sendMessage()">Envoyer</button>
            </div>
            <div class="emailbox">
                <h3>Envoyer un mail</h3>
                <input type="text" id="name" placeholder="Votre nom">
                <input type="email" id="email" placeholder="Votre email">
                <textarea id="message" placeholder="Votre message"></textarea>
                <button onclick="sendEmail()">Envoyer</button>
            </div>
        </div>
        <footer>
            <p>&copy; 2023 Sportify. Tous droits réservés.</p>
        </footer>
    </div>

    <script>
        const senderId = 1; // Remplacez par l'ID de l'utilisateur connecté
        const receiverId = 2; // Remplacez par l'ID du destinataire (par exemple, le coach)

        function sendMessage() {
            const messageBox = document.getElementById('messageBox');
            const messageInput = document.getElementById('messageInput');
            const message = messageInput.value;
            const timestamp = new Date().toLocaleTimeString();

            if (message.trim() !== '') {
                const xhr = new XMLHttpRequest();
                xhr.open("POST", "send_message.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        const messageElement = document.createElement('p');
                        messageElement.textContent = `Vous: ${message} ${timestamp}`;
                        messageBox.appendChild(messageElement);

                        // Scroll to the bottom
                        messageBox.scrollTop = messageBox.scrollHeight;

                        // Clear the input
                        messageInput.value = '';
                    }
                };

                xhr.send(`sender_id=${senderId}&receiver_id=${receiverId}&message=${message}`);
            }
        }

        function loadMessages() {
            const messageBox = document.getElementById('messageBox');
            const xhr = new XMLHttpRequest();
            xhr.open("GET", `get_messages.php?sender_id=${senderId}&receiver_id=${receiverId}`, true);

            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    const messages = JSON.parse(xhr.responseText);
                    messageBox.innerHTML = '';
                    messages.forEach(msg => {
                        const messageElement = document.createElement('p');
                        messageElement.textContent = `${msg.sender_id === senderId ? 'Vous' : 'Coach'}: ${msg.message} ${new Date(msg.timestamp).toLocaleTimeString()}`;
                        messageBox.appendChild(messageElement);
                    });

                    // Scroll to the bottom
                    messageBox.scrollTop = messageBox.scrollHeight;
                }
            };

            xhr.send();
        }

        function sendEmail() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    if (name.trim() !== '' && email.trim() !== '' && message.trim() !== '') {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "send_email.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                alert('Email envoyé et message sauvegardé !');
            }
        };

        xhr.send(`name=${name}&email=${email}&message=${message}&sender_id=${senderId}&receiver_id=${receiverId}`);
    } else {
        alert('Veuillez remplir tous les champs.');
    }
}

        // Charger les messages au chargement de la page
        window.onload = loadMessages;
    </script>
</body>
</html>
