
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Person Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #333;
            color: white;
            text-align: center;
        }
        .back-button {
            padding: 10px;
            margin: 5px;
            border-radius: 5px;
            border: none;
            font-size: 16px;
            background-color: green;
            color: white;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>CV</h1>
    <div id="person-info"></div>

    <script>
        function loadXMLDoc(filename) {
            return new Promise((resolve, reject) => {
                const xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        resolve(this.responseXML);
                    } else if (this.readyState == 4) {
                        reject("Failed to load XML file");
                    }
                };
                xhttp.open("GET", filename, true);
                xhttp.send();
            });
        }

        function displayPersonInfo(xml) {
            const person = xml.getElementsByTagName("personne")[0];
            const name = person.getElementsByTagName("nom")[0].textContent;
            const phone = person.getElementsByTagName("telephone")[0].textContent;
            const email = person.getElementsByTagName("email")[0].textContent;
            const address = person.getElementsByTagName("adresse")[0].textContent;
            const profile = person.getElementsByTagName("profil")[0].textContent;
            const competences = person.getElementsByTagName("competence")[0].textContent;
            const experiences = person.getElementsByTagName("experience")[0].textContent;

            const personInfo = `
                <h2>${name}</h2>
                <p>Téléphone: ${phone}</p>
                <p>Email: ${email}</p>
                <p>Address: ${address}</p>
                <p>Profile: ${profile}</p>
                <p>Competences: ${competences}</p>
                <p>Experiences: ${experiences}</p>
            `;

            document.getElementById("person-info").innerHTML = personInfo;
        }

        // Nouvelle fonction pour générer le nom du fichier XML en fonction des données XML
        function getXMLFileName() {
            const xmlName = `CV_6.xml`;
            return xmlName;
        }

        const xmlFileName = getXMLFileName();
        loadXMLDoc(xmlFileName)
            .then(xml => displayPersonInfo(xml))
            .catch(error => console.error(error));
    </script>
    <br>
    <a class="back-button" href="...">Retour</a>
    </body>
</html>