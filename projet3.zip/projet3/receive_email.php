<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projet";

// Créer une connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sender_id = $_POST['sender_id']; // L'ID de l'expéditeur (coach)
$receiver_id = $_POST['receiver_id']; // L'ID du destinataire (client)
$message_content = $_POST['message'];

$sql = "INSERT INTO messages (sender_id, receiver_id, message) VALUES ('$sender_id', '$receiver_id', '$message_content')";

if ($conn->query($sql) === TRUE) {
    echo "Message received and saved successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
