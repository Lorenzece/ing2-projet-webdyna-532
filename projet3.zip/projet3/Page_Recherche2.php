<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche - Sportify</title>
    <link rel="stylesheet" href="style2.css">
    <script>
        function toggleDisplay(id) {
            var element = document.getElementById(id);
            if (element.style.display === 'block') {
                element.style.display = 'none';
            } else {
                element.style.display = 'block';
            }
        }

        function searchCoach() {
            const searchTerm = document.getElementById('search-input').value;
            fetch(`http://localhost/projet_info/Recherche.php?searchTerm=${encodeURIComponent(searchTerm)}`)
                .then(response => response.json())
                .then(coaches => {
                    const resultsDiv = document.getElementById('results');
                    resultsDiv.innerHTML = '';
                    if (coaches.length > 0) {
                        coaches.forEach(coach => {
                            const card = document.querySelector("[data-user-template]").content.cloneNode(true).children[0];
                            card.querySelector("[data-header]").textContent = coach.Nom;
                            card.querySelector("[data-body]").textContent = coach.Activité;
                            card.addEventListener('click', () => showDetails(coach));
                            resultsDiv.appendChild(card);
                        });
                    } else {
                        resultsDiv.innerHTML = 'Aucun coach trouvé';
                    }
                })
        }

        function showDetails(coach) {
            const detailsDiv = document.getElementById('coach-details');
            detailsDiv.innerHTML = `
                <h2>Détails du Coach</h2>
                <p><strong>Nom:</strong> ${coach.Nom}</p>
                <p><strong>Activité:</strong> ${coach.Activité}</p>
                <p><strong>Email:</strong> ${coach.courrier}</p>
                <p><strong>Téléphone:</strong> ${coach.téléphone}</p>
                <p><strong>Disponibilité:</strong> ${coach.disponibilité}</p>
                <button onclick="toggleDisplay('photo')">Afficher/Masquer la photo</button>
                <button onclick="toggleDisplay('cv')">Afficher/Masquer le CV</button>
                <img id="photo" src="${coach.Photo}" style="display:none; margin: 20px auto; max-width: 300px; display: block;">
                <div id="cv" style="display:none; margin: 20px auto; max-width: 400px; display: block;">
                    <embed src="${coach.CV}" type="application/pdf" width="100%" height="400px" />
                </div>
                <tr><td> ChatRoom:</td><td> <a href= chatroom.html> Chatroom</a></td></tr>
            `;
        }
    </script>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Recherche</h1>
        </header>
        <nav>
            <a href="<?php echo ($role == 'admin') ? 'admin.php' : (($role == 'coach') ? 'coach.php' : 'client.php'); ?>">Accueil</a>
            <a href="parcourir.php">Tout Parcourir</a>
           
            <a href="rendez-vous.php">Rendez-vous</a>
            <a href="<?php echo ($role == 'admin') ? 'compte_admin.php' : (($role == 'coach') ? 'compte_coach.php' : 'compte_client.php'); ?>">Votre Compte</a>
            <a href="Page_NoLogin.html">Déconnexion</a>
        </nav>
        <div class="content">
            <h2>Recherche</h2>
            <div class="search-container">
                <input type="text" id="search-input" placeholder="Nom ou Activité">
                <button onclick="searchCoach()">Rechercher</button>
            </div>
            <div id="results" class="results-container"></div>
            <div id="coach-details" class="details-container"></div>
        </div>
        <footer>
            <p>Contactez-nous par mail, téléphone, ou visitez-nous à notre adresse physique.</p>
        </footer>
    </div>

    <template data-user-template>
        <div class="card">
            <h3 data-header></h3>
            <p data-body></p>
        </div>
    </template>

</body>
</html>
