<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "projet";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("La connexion a échoué: " . $conn->connect_error);
}

$name_prenom = $_POST['Nom/Prénom'];
$email = $_POST['email'];
$adresse = $_POST['adresse'];
$pwd = $_POST['password'];
$etudiant = $_POST['etudiant'];

$sql = "SELECT MAX(id) AS max_id FROM login";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$new_id = $row['max_id'] + 1;

$sql = "INSERT INTO login (id, name, email, password, role, carte_etudiant, adresse) VALUES (?, ?, ?, ?, 'client', ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isssss", $new_id, $name_prenom, $email, $pwd, $etudiant, $adresse);

if ($stmt->execute()) {
    header("Location: connexion.php");
    exit();
} else {
    echo "Erreur : " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
