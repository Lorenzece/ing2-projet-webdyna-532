<?php
$db = new mysqli('localhost', 'root', 'root', 'projet');

if ($db->connect_error) {
    die('Erreur de connexion (' . $db->connect_errno . ') ' . $db->connect_error);
}
?>
