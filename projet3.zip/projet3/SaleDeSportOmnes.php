<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salle de sport Omnes - Sportify</title>
    <link rel="stylesheet" href="style2.css">
    <style>
        .card-custom {
            background-color: #1e1e1e;
            color: white;
            border: 1px solid #333;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }

        .card-custom h2, .card-custom p {
            color: white;
        }

        .card-custom button {
            background-color: #ffc107;
            color: black;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            font-weight: bold;
        }

        .card-custom button:hover {
            background-color: #ffca2c;
        }

        .service-item {
            background-color: #282828;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .service-item h4 {
            color: #1DB954;
        }

        .service-item p {
            color: #b3b3b3;
        }

        .carousel {
            position: relative;
            width: 100%;
            max-width: 500px;
            margin: auto;
            overflow: hidden;
            border-radius: 10px;
        }

        .carousel-images {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }

        .carousel-images div {
            min-width: 100%;
            box-sizing: border-box;
        }

        .carousel-images img {
            width: 100%;
            border-radius: 10px;
        }

        .carousel-buttons {
            position: absolute;
            width: 100%;
            top: 50%;
            display: flex;
            justify-content: space-between;
            transform: translateY(-50%);
        }

        .carousel-button {
            background-color: rgba(0, 0, 0, 0.5);
            border: none;
            color: white;
            font-size: 2em;
            cursor: pointer;
            padding: 10px;
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Salle de sport Omnes</h1>
        </header>
        <nav>
            <a href="<?php echo ($role == 'admin') ? 'admin.php' : (($role == 'coach') ? 'coach.php' : 'client.php'); ?>">Accueil</a>
            <a href="Page_Recherche2.php">Recherche</a>
            <a href="rendez-vous.php">Rendez-vous</a>
            <a href="<?php echo ($role == 'admin') ? 'compte_admin.php' : (($role == 'coach') ? 'compte_coach.php' : 'compte_client.php'); ?>">Votre Compte</a>
            <a href="Page_NoLogin.html">Déconnexion</a>
        </nav>
        <div class="content container mt-4">
            <div class="card-custom text-center">
                <img src="Photo_Caroussel/c01f9e2e-eb0b-443a-8935-a39b2a8715d5.png" class="img-fluid rounded mb-3" alt="Salle de sport Omnes">
                <h2>Salle de sport Omnes</h2>
                <p>Salle: G-001</p>
                <p>Téléphone: +33 01 22 33 44 55</p>
                <p>Email: salle.sport@omnessports.fr</p>
                <button id="showServices">Nos services</button>
            </div>
            <div id="services" class="mt-4">
                <div class="service-item">
                    <h4>Personnels de la salle de sport</h4>
                    <div class="carousel">
                        <div class="carousel-images">
                            <div>
                                <img src="Photo_Coach_Masculin/photo1.jpg" alt="Coach 1">
                                <div class="carousel-caption">
                                    <h5>Hercule Barbell</h5>
                                    <p>Musculation</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Féminin/photo2.jpg" alt="Coach 2">
                                <div class="carousel-caption">
                                    <h5>Eva Lucian</h5>
                                    <p>Fitness</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Masculin/photo3.jpg" alt="Coach 3">
                                <div class="carousel-caption">
                                    <h5>Pierre Lonné</h5>
                                    <p>Biking</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Féminin/photo4.jpg" alt="Coach 4">
                                <div class="carousel-caption">
                                    <h5>Celine Pulsar</h5>
                                    <p>Cardio-training</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Masculin/photo5.jpg" alt="Coach 5">
                                <div class="carousel-caption">
                                    <h5>Claude Hernandez</h5>
                                    <p>Cours Collectifs</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Féminin/photo6.jpg" alt="Coach 6">
                                <div class="carousel-caption">
                                    <h5>6 Sophie Bleur</h5>
                                    <p>Alex Bill</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Masculin/photo7.jpg" alt="Coach 7">
                                <div class="carousel-caption">
                                    <h5>Alex Bill</h5>
                                    <p>Football</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Féminin/photo8.jpg" alt="Coach 8">
                                <div class="carousel-caption">
                                    <h5>Lea Bigorne</h5>
                                    <p>Rugby</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Masculin/photo9.jpg" alt="Coach 9">
                                <div class="carousel-caption">
                                    <h5>Pascal Set</h5>
                                    <p>Tennis</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Féminin/photo10.jpg" alt="Coach 10">
                                <div class="carousel-caption">
                                    <h5>Marine Plouf</h5>
                                    <p>Natation</p>
                                </div>
                            </div>
                            <div>
                                <img src="Photo_Coach_Masculin/photo11.jpg" alt="Coach 11">
                                <div class="carousel-caption">
                                    <h5>Dorian Vaché</h5>
                                    <p>Plongeon</p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-buttons">
                            <button class="carousel-button" onclick="moveCarousel(-1)">&#8249;</button>
                            <button class="carousel-button" onclick="moveCarousel(1)">&#8250;</button>
                        </div>
                    </div>
                </div>
                <div class="service-item">
                    <h4>Horaire de la gym</h4>
                    <p>La salle de sport est ouverte du lundi au vendredi de 6h00 à 22h00, et le samedi de 8h00 à 20h00. Elle est fermée le dimanche.</p>
                </div>
                <div class="service-item">
                    <h4>Règles sur l’utilisation des machines et la propreté</h4>
                    <p>Veuillez respecter les autres utilisateurs et suivre les instructions affichées sur chaque machine, serviette obligatoire sous peine d'exclusion.</p>
                </div>
                <div class="service-item">
                    <h4>Nouveaux clients</h4>
                    <p>Le questionnaire nous aide à comprendre vos besoins et à adapter nos services en conséquence. Vous pouvez le remplir à l'accueil des notre salle</p>
                </div>
                <div class="service-item">
                    <h4>Alimentation et nutrition</h4>
                    <p>Conseils et programmes nutritionnels disponibles en salle, pour votre santé mangez 5 fruits et légumes par jour.</p>
                </div>
            </div>
        </div>
        <footer>
            <p>Contactez-nous par mail, téléphone, ou visitez-nous à notre adresse physique.</p>
        </footer>
    </div>
    <script>
        let currentIndex = 0;

        function moveCarousel(step) {
            const carouselImages = document.querySelector('.carousel-images');
            const totalImages = carouselImages.children.length;
            currentIndex = (currentIndex + step + totalImages) % totalImages;
            carouselImages.style.transform = `translateX(${-currentIndex * 100}%)`;
        }

        document.addEventListener('DOMContentLoaded', function(){
            document.getElementById('services').style.display = 'none';
            document.getElementById('showServices').addEventListener('click', function() {
                const servicesDiv = document.getElementById('services');
                servicesDiv.style.display = servicesDiv.style.display === 'none' ? 'block' : 'none';
            });
        });
    </script>
</body>
</html>
