<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: Page_Connexion.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "projet";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("La connexion a échoué: " . $conn->connect_error);
}

$email = $_SESSION['email'];

$sql = "SELECT role FROM login WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$role = $user['role'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Sports de Compétition - Sportify</title>
    <link rel="stylesheet" href="style2.css">
    <script>
        function toggleDisplay(id) {
            var element = document.getElementById(id);
            if (element.style.display === 'block') {
                element.style.display = 'none';
            } else {
                element.style.display = 'block';
            }
        }

        function showDetails(activity) {
            var detailsDiv = document.getElementById('details-' + activity);
            detailsDiv.style.display = detailsDiv.style.display === 'block' ? 'none' : 'block';
        }
    </script>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Sports de Compétition</h1>
        </header>
        <nav>
            <a href="<?php echo ($role == 'admin') ? 'admin.php' : (($role == 'coach') ? 'coach.php' : 'client.php'); ?>">Accueil</a>
            <a href="Page_Recherche2.php">Recherche</a>
            <a href="rendez-vous.php">Rendez-vous</a>
            <a href="<?php echo ($role == 'admin') ? 'compte_admin.php' : (($role == 'coach') ? 'compte_coach.php' : 'compte_client.php'); ?>">Votre Compte</a>
            <a href="Page_NoLogin.html">Déconnexion</a>
        </nav>
        <div class="content">
            <h2>Sports de Compétition</h2>
            <div class="categories">
                <button class="activity" onclick="toggleDisplay('basketball')">Basketball</button>
                <div id="basketball" style="display: none;">
                    <div class="responsible">
                        <h3>Responsable : <a href="javascript:void(0)" onclick="showDetails('basketball')">Voir responsable</a></h3>
                        <div class="details" id="details-basketball" style="display: none;">
                            <?php showResponsibleDetails('basketball'); ?>
                        </div>
                    </div>
                </div>
                
                <button class="activity" onclick="toggleDisplay('football')">Football</button>
                <div id="football" style="display: none;">
                    <div class="responsible">
                        <h3>Responsable : <a href="javascript:void(0)" onclick="showDetails('football')">Voir responsable</a></h3>
                        <div class="details" id="details-football" style="display: none;">
                            <?php showResponsibleDetails('football'); ?>
                        </div>
                    </div>
                </div>
                
                <button class="activity" onclick="toggleDisplay('rugby')">Rugby</button>
                <div id="rugby" style="display: none;">
                    <div class="responsible">
                        <h3>Responsable : <a href="javascript:void(0)" onclick="showDetails('rugby')">Voir responsable</a></h3>
                        <div class="details" id="details-rugby" style="display: none;">
                            <?php showResponsibleDetails('rugby'); ?>
                        </div>
                    </div>
                </div>
                
                <button class="activity" onclick="toggleDisplay('tennis')">Tennis</button>
                <div id="tennis" style="display: none;">
                    <div class="responsible">
                        <h3>Responsable : <a href="javascript:void(0)" onclick="showDetails('tennis')">Voir responsable</a></h3>
                        <div class="details" id="details-tennis" style="display: none;">
                            <?php showResponsibleDetails('tennis'); ?>
                        </div>
                    </div>
                </div>
                
                <button class="activity" onclick="toggleDisplay('natation')">Natation</button>
                <div id="natation" style="display: none;">
                    <div class="responsible">
                        <h3>Responsable : <a href="javascript:void(0)" onclick="showDetails('natation')">Voir responsable</a></h3>
                        <div class="details" id="details-natation" style="display: none;">
                            <?php showResponsibleDetails('natation'); ?>
                        </div>
                    </div>
                </div>
                
                <button class="activity" onclick="toggleDisplay('plongeon')">Plongeon</button>
                <div id="plongeon" style="display: none;">
                    <div class="responsible">
                        <h3>Responsable : <a href="javascript:void(0)" onclick="showDetails('plongeon')">Voir responsable</a></h3>
                        <div class="details" id="details-plongeon" style="display: none;">
                            <?php showResponsibleDetails('plongeon'); ?>
                        </div>
                    </div>
                </div>
            </div>
            <a href="parcourir.php" class="back-button">Retour tout parcourir</a>
        </div>
        <footer>
            <p>Contactez-nous par mail, téléphone, ou visitez-nous à notre adresse physique.</p>
        </footer>
    </div>

<?php
function showResponsibleDetails($activity) {
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "projet";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $activityIds = [
        'basketball' => 6,
        'football' => 7,
        'rugby' => 8,
        'tennis' => 9,
        'natation' => 10,
        'plongeon' => 11
    ];

    if (array_key_exists($activity, $activityIds)) {
        $id = $activityIds[$activity];

        $sql = "SELECT * FROM coach WHERE ID = $id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo '<table class="center" border="1">';
            echo "<tr>";
            echo "<th>Nom</th>";
            echo "<th>Activité</th>";
            echo "<th>Adresse bureau</th>";
            echo "<th>Disponibilité</th>";
            echo "<th>Courrier</th>";
            echo "<th>Téléphone</th>";
            echo "<th>Photo</th>";
            echo "<th>CV</th>";
            echo "</tr>";
            
            while ($data = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($data['Nom']) . "</td>";
                echo "<td>" . htmlspecialchars($data['Activité']) . "</td>";
                echo "<td>" . htmlspecialchars($data['adresse bureau']) . "</td>";
                echo "<td>" . htmlspecialchars($data['disponibilité']) . "</td>";
                echo "<td>" . htmlspecialchars($data['courrier']) . "</td>";
                echo "<td>" . htmlspecialchars($data['téléphone']) . "</td>";
                echo "<td><img src='" . htmlspecialchars($data['Photo']) . "' alt='Photo' width='50'></td>";
                echo "<td><a href='" . htmlspecialchars($data['CV']) . "' target='_blank'>Voir CV</a></td>";
                echo "<tr><td> ChatRoom:</td><td> <a href= chatroom.html> Chatroom</a></td></tr>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "Aucun responsable trouvé pour cette activité.";
        }
    } else {
        echo "Activité non reconnue.";
    }

    $conn->close();
}
?>
</body>
</html>
