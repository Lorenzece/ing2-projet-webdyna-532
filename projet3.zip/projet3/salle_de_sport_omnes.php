<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Salle de sport Omnes - Sportify</title>
    <link rel="stylesheet" href="style2.css">
    <script>
        function toggleDisplay(id) {
            var element = document.getElementById(id);
            if (element.style.display === 'block') {
                element.style.display = 'none';
            } else {
                element.style.display = 'block';
            }
        }

        function showDetails(id) {
            var detailsDiv = document.getElementById('details-' + id);
            detailsDiv.style.display = detailsDiv.style.display === 'block' ? 'none' : 'block';
        }
    </script>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Salle de sport Omnes</h1>
        </header>
        <nav>
            <a href="<?php echo ($role == 'admin') ? 'admin.php' : (($role == 'coach') ? 'coach.php' : 'client.php'); ?>">Accueil</a>
            <a href="Page_Recherche2.php">Recherche</a>
            <a href="rendez-vous.php">Rendez-vous</a>
            <a href="<?php echo ($role == 'admin') ? 'compte_admin.php' : (($role == 'coach') ? 'compte_coach.php' : 'compte_client.php'); ?>">Votre Compte</a>
            <a href="Page_NoLogin.html">Déconnexion</a>
        </nav>
        <div class="content">
            <h2>Salle de sport Omnes</h2>
            <div class="section">
                <a href="saleDeSportOmnes.php"> <p>En savoir plus en details sur la salle de sport Omnes</p></a>
                <h2>Services Disponibles</h2>
                <div class="categories">
                    <button class="activity" onclick="toggleDisplay('regles')">Règles sur l’utilisation des machines</button>
                    <div id="regles" style="display: none;">
                        <p><strong>Q:</strong> Puis-je utiliser les machines librement?<br>
                        <strong>R:</strong> Oui, mais veuillez respecter les autres utilisateurs et suivre les instructions affichées sur chaque machine.</p>
                        
                        <p><strong>Q:</strong> Dois-je nettoyer les machines après utilisation?<br>
                        <strong>R:</strong> Oui, il est obligatoire de désinfecter les machines après chaque utilisation pour garantir l'hygiène.</p>

                        <p><strong>Q:</strong> Puis-je réserver une machine?<br>
                        <strong>R:</strong> Non, les machines sont disponibles selon le principe du premier arrivé, premier servi.</p>
                    </div>
                    
                    <button class="activity" onclick="toggleDisplay('horaire')">Horaire de la gym</button>
                    <div id="horaire" style="display: none;">
                        <p><strong>Q:</strong> Quels sont les horaires d'ouverture de la salle de sport?<br>
                        <strong>R:</strong> La salle de sport est ouverte du lundi au vendredi de 6h00 à 22h00, et le samedi de 8h00 à 20h00. Elle est fermée le dimanche.</p>
                        
                        <p><strong>Q:</strong> Y a-t-il des heures réservées pour les cours?<br>
                        <strong>R:</strong> Oui, les cours collectifs ont lieu de 18h00 à 20h00 en semaine. Veuillez consulter le planning affiché pour plus de détails.</p>

                        <p><strong>Q:</strong> Puis-je accéder à la salle de sport en dehors des heures d'ouverture?<br>
                        <strong>R:</strong> Non, pour des raisons de sécurité, l'accès est strictement limité aux heures d'ouverture.</p>
                    </div>

                    <button class="activity" onclick="toggleDisplay('questionnaire')">Questionnaires pour les nouveaux utilisateurs</button>
                    <div id="questionnaire" style="display: none;">
                        <p><strong>Q:</strong> Pourquoi dois-je remplir un questionnaire?<br>
                        <strong>R:</strong> Le questionnaire nous aide à comprendre vos besoins et à adapter nos services en conséquence.</p>

                        <p><strong>Q:</strong> Que contient le questionnaire?<br>
                        <strong>R:</strong> Il contient des questions sur votre état de santé général, vos objectifs de fitness, et vos expériences passées en salle de sport.</p>

                        <p><strong>Q:</strong> Comment puis-je remplir le questionnaire?<br>
                        <strong>R:</strong> Vous pouvez remplir le questionnaire en ligne en version papier disponible à l'accueil.</p>
                    </div>
                </div>
            </div>

            <div class="section">
                <h2>Coordonnées des Responsables</h2>
                <?php
                // Nom de la base de données
                $database = "coaches";

                // Connexion au serveur
                $db_handle = mysqli_connect('localhost', 'root', 'root');

                if ($db_handle) {
                    $db_found = mysqli_select_db($db_handle, $database);

                    // Si la base de données existe, faire le traitement
                    if ($db_found) {
                        $sql = "SELECT * FROM coach";
                        $result = mysqli_query($db_handle, $sql);

                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($data = mysqli_fetch_assoc($result)) {
                                echo "<div class='responsible'>";
                                echo "<button class='activity' onclick=\"showDetails('" . htmlspecialchars($data['Nom']) . "')\">Responsable : " . htmlspecialchars($data['Nom']) . "</button>";
                                echo "<div class='details' id='details-" . htmlspecialchars($data['Nom']) . "' style='display:none;'>";
                                echo "<table>";
                                echo "<tr><td>Nom:</td><td>" . htmlspecialchars($data['Nom']) . "</td></tr>";
                                echo "<tr><td>Activité:</td><td>" . htmlspecialchars($data['Activité']) . "</td></tr>";
                                echo "<tr><td>Adresse bureau:</td><td>" . htmlspecialchars($data['adresse bureau']) . "</td></tr>";
                                echo "<tr><td>Disponibilité:</td><td>" . htmlspecialchars($data['disponibilité']) . "</td></tr>";
                                echo "<tr><td>Courrier:</td><td>" . htmlspecialchars($data['courrier']) . "</td></tr>";
                                echo "<tr><td>Téléphone:</td><td>" . htmlspecialchars($data['téléphone']) . "</td></tr>";
                                $photoPath = htmlspecialchars($data['Photo']);
                                echo "<tr><td>Photo:</td><td><img src='$photoPath' alt='Photo' style='max-width:100px;'></td></tr>";
                                echo "<tr><td>CV:</td><td><a href='" . htmlspecialchars($data['CV']) . "' target='_blank'>Voir CV</a></td></tr>";
                                echo "<tr><td> ChatRoom:</td><td> <a href= chatroom.html> Chatroom</a></td></tr>";
                                echo "</table>";
                                echo "</div>";
                                echo "</div>";
                            }
                        } else {
                            echo "Aucun responsable trouvé.";
                        }
                    } else {
                        echo "Base de données non trouvée";
                    }

                    // Fermer la connexion
                    mysqli_close($db_handle);
                } else {
                    die("Échec de la connexion au serveur : " . mysqli_connect_error());
                }
                ?>
            </div>

            <a href="javascript:history.back()" class="back-button">Retour tout parcourir</a>
        </div>
        <footer>
            <p>Contactez-nous par mail, téléphone, ou visitez-nous à notre adresse physique.</p>
        </footer>
    </div>
</body>
</html>
