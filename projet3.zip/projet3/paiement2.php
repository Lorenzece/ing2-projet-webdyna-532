<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "projet";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $nom = $_SESSION['name'];
    $prenom = $_SESSION['prenom'];
    $adresse_ligne1 = $_SESSION['adresse_ligne1'];
    $adresse_ligne2 = $_SESSION['adresse_ligne2'];
    $ville = $_SESSION['ville'];
    $code_postal = $_SESSION['code_postal'];
    $pays = $_SESSION['pays'];
    $telephone = $_SESSION['telephone'];
    $carte_etudiant = $_SESSION['carte_etudiant'];
    $type_carte = $_POST['type_carte'];
    $card_number = $_POST['card_number'];
    $card_name = $_POST['card_name'];
    $expiry_date = $_POST['expiry_date'] . '-01';
    $cvv = $_POST['cvv'];

   
    $sql1 = "INSERT INTO coordonneespaiement ( nom, prenom, adresse_ligne1, adresse_ligne2, ville, code_postal, pays, numero_telephone, carte_etudiant) 
             VALUES ( '$nom', '$prenom', '$adresse_ligne1', '$adresse_ligne2', '$ville', '$code_postal', '$pays', '$telephone', '$carte_etudiant')";

    
    $sql2 = "INSERT INTO detailspaiement ( type_carte, numero_carte, nom_sur_carte, date_expiration, code_securite) 
             VALUES ( '$type_carte', '$card_number', '$card_name', '$expiry_date', '$cvv')";

    if ($conn->query($sql1) === TRUE && $conn->query($sql2) === TRUE) {
        header("Location: rendezvous.php");
        exit();
    } else {
        echo "Erreur: " . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement - Sportify</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #191414;
            color: white;
        }
        .wrapper {
            width: 100%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        header {
            background-color: #191414;
            padding: 20px;
            text-align: center;
            border-bottom: 2px solid #1DB954;
            width: 100%;
        }
        header h1 {
            margin: 0;
            font-size: 2em;
            color: white;
        }
        header span {
            color: #1DB954;
        }
        .payment-container {
            background-color: #282828;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
            width: 400px;
            margin-top: 20px;
        }
        .payment-container h2 {
            margin: 0 0 20px 0;
            color: #1DB954;
            text-align: center;
        }
        .payment-container label {
            display: block;
            margin-bottom: 10px;
            color: #b3b3b3;
        }
        .payment-container input,
        .payment-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: none;
            border-radius: 5px;
        }
        .payment-container button {
            width: 100%;
            padding: 10px;
            background-color: #1DB954;
            border: none;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        .payment-container button:hover {
            background-color: #1ed760;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Paiement</h1>
        </header>
        <div class="payment-container">
            <h2>Détails de la Carte</h2>
            <form action="paiement2.php" method="POST">
                <label for="type-carte">Type de Carte :</label>
                <select id="type-carte" name="type_carte" required>
                    <option value="Visa">Visa</option>
                    <option value="MasterCard">MasterCard</option>
                    <option value="American Express">American Express</option>
                </select>
                <label for="card-number">Numéro de Carte :</label>
                <input type="text" id="card-number" name="card_number" required>
                <label for="card-name">Nom sur la Carte :</label>
                <input type="text" id="card-name" name="card_name" required>
                <label for="expiry-date">Date d'Expiration :</label>
                <input type="month" id="expiry-date" name="expiry_date" required>
                <label for="cvv">Code de Sécurité (CVV) :</label>
                <input type="text" id="cvv" name="cvv" required>
                <button type="submit">Payer</button>
            </form>
        </div>
    </div>
</body>
</html>
