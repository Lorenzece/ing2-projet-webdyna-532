<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "projet";

// Créer une connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$email = $_POST['email'];
$message_content = $_POST['message'];
$receiver_id = $_POST['receiver_id']; // L'ID du destinataire (coach)
$sender_id = $_POST['sender_id']; // L'ID de l'expéditeur (client)

$subject = "Nouveau message de $name";
$headers = "From: $email";

// Envoyer le courriel
mail($email, $subject, $message_content, $headers);

// Enregistrer le message dans la base de données
$sql = "INSERT INTO messages (sender_id, receiver_id, message) VALUES ('$sender_id', '$receiver_id', '$message_content')";

if ($conn->query($sql) === TRUE) {
    echo "Email sent and message saved successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
