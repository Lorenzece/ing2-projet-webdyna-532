<?php
header('Content-Type: application/json');

// Configuration de la base de données
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "coaches";

// Création de la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("La connexion a échoué: " . $conn->connect_error);
}

$searchTerm = $_GET['searchTerm'];

$sql = "SELECT * FROM coach WHERE Nom LIKE '%$searchTerm%' OR Activité LIKE '%$searchTerm%' OR Salle de sport LIKE '%$searchTerm%'";
$result = $conn->query($sql);

$coach = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $coach[] = $row;
    }
}

$conn->close();

echo json_encode($coach);
?>
