<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: Page_Connexion.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "projet";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("La connexion a échoué: " . $conn->connect_error);
}

$email = $_SESSION['email'];

$sql = "SELECT role FROM login WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$role = $user['role'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Activités Sportives - Sportify</title>
    <link rel="stylesheet" href="style2.css">
    <script>
        function toggleDisplay(id) {
            var element = document.getElementById(id);
            if (element.style.display === 'block') {
                element.style.display = 'none';
            } else {
                element.style.display = 'block';
            }
        }
    </script>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1><span>Sportify:</span> Activités Sportives</h1>
        </header>
        <nav>
            <a href="<?php echo ($role == 'admin') ? 'admin.php' : (($role == 'coach') ? 'coach.php' : 'client.php'); ?>">Accueil</a>
            <a href="Page_Recherche2.php">Recherche</a>
            <a href="connexion.php">Rendez-vous</a>
            <a href="<?php echo ($role == 'admin') ? 'compte_admin.php' : (($role == 'coach') ? 'compte_coach.php' : 'compte_client.php'); ?>">Votre Compte</a>
            <a href="Page_NoLogin.html">Déconnexion</a>
        </nav>
        <div class="content">
            <h2>Activités Sportives</h2>
            <div class="categories">
                <button class="activity" onclick="toggleDisplay('musculation')">Musculation</button>
                <div id="musculation" style="display: none;">
                    <p>La musculation est une pratique sportive visant à développer la force musculaire, l'endurance et la masse musculaire...</p>
                    <div class="responsible">
                        <h3>Responsable de cette activité :</h3>
                        <?php showResponsibleDetails('musculation'); ?>
                    </div>
                </div>
                
                <button class="activity" onclick="toggleDisplay('fitness')">Fitness</button>
                <div id="fitness" style="display: none;">
                    <p>Le fitness est une pratique visant à améliorer la condition physique générale à travers des exercices variés...</p>
                    <div class="responsible">
                        <h3>Responsable de cette activité :</h3>
                        <?php showResponsibleDetails('fitness'); ?>
                    </div>
                </div>

                <button class="activity" onclick="toggleDisplay('biking')">Biking</button>
                <div id="biking" style="display: none;">
                    <p>Le biking, ou cyclisme, est une activité sportive qui consiste à utiliser un vélo pour le loisir, la compétition ou comme moyen de transport...</p>
                    <div class="responsible">
                        <h3>Responsable de cette activité :</h3>
                        <?php showResponsibleDetails('biking'); ?>
                    </div>
                </div>

                <button class="activity" onclick="toggleDisplay('cardio-training')">Cardio-Training</button>
                <div id="cardio-training" style="display: none;">
                    <p>Le cardio-training regroupe l'ensemble des activités physiques visant à améliorer l'endurance et la capacité cardiovasculaire...</p>
                    <div class="responsible">
                        <h3>Responsable de cette activité :</h3>
                        <?php showResponsibleDetails('cardio-training'); ?>
                    </div>
                </div>

                <button class="activity" onclick="toggleDisplay('cours-collectifs')">Cours Collectifs</button>
                <div id="cours-collectifs" style="display: none;">
                    <p>Les cours collectifs sont des séances d'exercice en groupe dirigées par un instructeur...</p>
                    <div class="responsible">
                        <h3>Responsable de cette activité :</h3>
                        <?php showResponsibleDetails('cours-collectifs'); ?>
                    </div>
                </div>
            </div>
            <a class="back-button" href="parcourir.php">Retour tout parcourir</a>
        </div>
        <footer>
            <p>Contactez-nous par mail, téléphone, ou visitez-nous à notre adresse physique.</p>
        </footer>
    </div>

    <?php
    function showResponsibleDetails($activity) {
        $servername = "localhost";
        $username = "root";
        $password = "root";
        $dbname = "projet";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $activityIds = [
            'musculation' => 1,
            'fitness' => 2,
            'biking' => 3,
            'cardio-training' => 4,
            'cours-collectifs' => 5
        ];

        if (array_key_exists($activity, $activityIds)) {
            $id = $activityIds[$activity];

            $sql = "SELECT * FROM coach WHERE ID = $id";
            $result = mysqli_query($conn, $sql);

            if ($result->num_rows > 0) {
                echo '<table>';
                while ($data = mysqli_fetch_assoc($result)) {
                    echo "<tr><td>Nom:</td><td>" . $data['Nom'] . "</td></tr>";
                    echo "<tr><td>Activité:</td><td>" . $data['Activité'] . "</td></tr>";
                    echo "<tr><td>Adresse bureau:</td><td>" . $data['adresse bureau'] . "</td></tr>";
                    echo "<tr><td>Disponibilité:</td><td>" . $data['disponibilité'] . "</td></tr>";
                    echo "<tr><td>Courrier:</td><td>" . $data['courier'] . "</td></tr>";
                    echo "<tr><td>Téléphone:</td><td>" . $data['téléphone'] . "</td></tr>";
                    echo "<tr><td>Photo:</td><td><img src='" . $data['Photo'] . "' alt='Photo'></td></tr>";
                    echo "<tr><td>CV:</td><td><a href='" . $data['CV'] . "' target='_blank'>Voir CV</a></td></tr>";
                    echo "<tr><td>CV: format ecrit : </td><td><a href='affichage_CV_" . $data['ID'] . ".php' target='_blank'>Cv Format Ecrit</a></td></tr>";
                    echo "<tr><td> ChatRoom:</td><td> <a href= chatroom.php> Chatroom</a></td></tr>";
                }
                echo '</table>';
            } else {
                echo "Aucun responsable trouvé pour cette activité.";
            }
        } else {
            echo "Activité non reconnue.";
        }

        $conn->close();
    }
    ?>
</body>
</html>
